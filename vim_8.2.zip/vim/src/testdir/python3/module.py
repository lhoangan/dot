import before_1
dir = '3'
