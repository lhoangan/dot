README_os2.txt for version 8.2 of Vim: Vi IMproved.

This file used to explain the installation of Vim on OS/2 systems.
However, support for OS/2 has been removed in patch 7.4.1008.
See "README.txt" for general information about Vim.
