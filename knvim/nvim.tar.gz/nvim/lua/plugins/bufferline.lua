-------------------------------------------------------------------------------
-- Bufferline on the top
-- akinsho/bufferline.nvim
-------------------------------------------------------------------------------
-- vim.opt.termguicolors = true

require('bufferline').setup({
    options = {
        separator_style = 'slant'
    }
})
