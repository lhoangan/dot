#!/usr/bin/env bash

[ -x "$(which oc)" ] && eval "$(oc completion bash)" 
