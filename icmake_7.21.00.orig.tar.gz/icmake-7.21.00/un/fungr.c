#include "icmun.h"

void fun_gr ()
{
    puts ("        gr");
}
