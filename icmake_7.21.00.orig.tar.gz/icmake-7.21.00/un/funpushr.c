#include "icmun.h"

void fun_push_reg ()
{
    puts ("        push reg");
}
