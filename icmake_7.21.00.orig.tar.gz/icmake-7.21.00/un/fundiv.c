#include "icmun.h"

void fun_div ()
{
    puts ("        div");
}
