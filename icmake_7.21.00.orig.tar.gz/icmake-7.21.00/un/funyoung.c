#include "icmun.h"

void fun_younger ()
{
    puts ("        younger");
}
