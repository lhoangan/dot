#include "icmun.h"

void fun_bnot ()
{
    puts ("        not");
}
