#include "icmun.h"

void fun_exit ()
{
    puts ("        exit");
}
