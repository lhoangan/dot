#include "icmun.h"

void fun_mod ()
{
    puts ("        mod");
}
