#include "icmun.h"

void fun_umin ()
{
    puts ("        umin");
}
