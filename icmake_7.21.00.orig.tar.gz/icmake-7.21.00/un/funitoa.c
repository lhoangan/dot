#include "icmun.h"

void fun_itoa ()
{
    puts ("        itoa");
}
