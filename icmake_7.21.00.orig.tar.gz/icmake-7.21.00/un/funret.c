#include "icmun.h"

void fun_ret ()
{
    puts ("        ret");
}
