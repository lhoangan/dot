#include "icmun.h"

void fun_smeq ()
{
    puts ("        smeq");
}
