#ifndef _INCLUDED_ICRSSDEF_H_
#define _INCLUDED_ICRSSDEF_H_

#ifndef _GNU_SOURCE
#define _GNU_SOURCE
#endif

#include <ctype.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "icrss.h"

#endif
