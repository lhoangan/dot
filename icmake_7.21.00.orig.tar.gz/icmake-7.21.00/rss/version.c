/*
                                V E R S I O N . C
*/

#include "../rss/icrss.h"
#include "../tmp/INSTALL.im"

char
    version[] = VERSION,
    release[] = YEARS;
