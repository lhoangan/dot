#include "var.ih"

UNS16 varCount(VAR_ *var)
{
    return var->vu.i->count;
}
