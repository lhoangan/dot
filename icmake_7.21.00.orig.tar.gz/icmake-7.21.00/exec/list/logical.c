#include "list.ih"

int listLogical(LISTVAR_ const *lhs)
{
    return size(lhs);
}
