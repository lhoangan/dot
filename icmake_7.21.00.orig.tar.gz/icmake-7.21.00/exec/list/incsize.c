#include "list.ih"

void incsize(LISTVAR_ *list)
{
    ++size(list);
}
