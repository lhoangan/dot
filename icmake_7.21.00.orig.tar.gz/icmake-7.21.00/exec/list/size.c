#include "list.ih"

size_t listSize(LISTVAR_ const *list)
{
    return size(list);
}
