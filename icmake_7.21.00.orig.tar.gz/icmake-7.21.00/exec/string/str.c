#include "string.ih"

char *stringStr(STRINGVAR_ const *lhs)
{
    return  str(lhs);
}
