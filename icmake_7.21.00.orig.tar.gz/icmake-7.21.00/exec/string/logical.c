#include "string.ih"

int stringLogical(STRINGVAR_ const *lhs)
{
    return *str(lhs);
}
