#ifndef _INCLUDED_OPCODEFUN_H_
#define _INCLUDED_OPCODEFUN_H_

void    process(void);

#endif
