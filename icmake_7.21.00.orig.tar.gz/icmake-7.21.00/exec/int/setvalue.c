#include "int.h"

void intSetValue(INTVAR_ *lhs, int value)
{
    lhs->vu.intval = value;
}
