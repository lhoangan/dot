#include "int.h"

int intValue(INTVAR_ const *lhs)
{
    return lhs->vu.intval;
}
