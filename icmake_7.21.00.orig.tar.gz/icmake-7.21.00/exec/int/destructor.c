#include "int.h"

void intDestructor(VAR_ *var)
{}

