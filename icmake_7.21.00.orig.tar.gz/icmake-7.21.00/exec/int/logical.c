#include "int.h"

int intLogical(INTVAR_ const *lhs)
{
    return lhs->vu.intval;
}
