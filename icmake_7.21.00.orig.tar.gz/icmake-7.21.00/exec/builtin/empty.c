void fun_empty (void)
{}
