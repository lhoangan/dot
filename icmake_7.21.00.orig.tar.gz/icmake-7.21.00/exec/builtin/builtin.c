#include "builtin.ih"

void builtin(size_t funnr)
{
    builtinfun[funnr]();
}

